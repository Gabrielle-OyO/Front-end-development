Tomcat是一个Web服务器，用于搭建部署网站，用户可以直接通过互联网访问网站

先打开终端，启动tomcat软件：
cd  Desktop/apache-tomcat-6.0.33/bin/
bash  startup.sh 

验证：
在浏览器中输入如下地址：http://127.0.0.1:8080
注：8080是Tomcat默认使用的端口号


在webapps目录下创建一个文件夹，如itany，然后将网页放到此文件夹中
访问自己的网站：http://127.0.0.1:8080/itany/02.writeCookie.html



常识：
ifconfig 查看ip地址
127.0.0.1 或 localhost 表示本机

