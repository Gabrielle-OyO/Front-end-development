console.log("welcome to wbs16073!");

/*
	关于路径问题：
	1.js是根据引入它的html文件所在位置
	2.css是根据当前css文件所在位置
*/