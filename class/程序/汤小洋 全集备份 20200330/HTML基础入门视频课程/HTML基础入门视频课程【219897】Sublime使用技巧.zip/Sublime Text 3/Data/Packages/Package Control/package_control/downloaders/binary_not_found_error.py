class BinaryNotFoundError(Exception):
    """If a necessary executable is not found in the PATH on the system"""

    pass
