let a  = 5;
console.log(a);

if(a>3){
    console.log('hello');
}

let names = ['tom','jack','alice'];
for(let name of names){
    console.log(name);
}

// alert(111); // Node只能运行ECMAScript，不支持DOM和BOM