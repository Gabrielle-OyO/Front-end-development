/**
 * 导入模块，使用require()
 */

//  var module1 = require('./modules/module1.js'); // 使用相对路径
var module2 = require('./modules/module2.js');

// console.log(module1);
// console.log(module1.a);

// console.log(module2);
console.log(module2.name);
console.log(module2.user);
console.log(module2.calc(13,25));

