module.exports = {
    name:'module3.js'
}