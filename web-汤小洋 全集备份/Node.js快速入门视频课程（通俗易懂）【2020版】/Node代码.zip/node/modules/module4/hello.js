module.exports = {
    name:'hello.js'
}