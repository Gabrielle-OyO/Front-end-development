/**
 * 练习：自定义计算器模块
 */
// var calc = require('./modules/calculator');
var calc = require('calculator');


var a = 5;
var b = 8;

console.log(calc.add(a,b));
console.log(calc.multiply(a,b));

