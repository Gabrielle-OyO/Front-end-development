package com.itany.dao;

import java.util.List;

import com.itany.entity.TrainItem;

/**
 * TrainItemDao接口
 * @author appleuser
 *
 */
public interface TrainItemDao {
	public List<TrainItem> selectAll();
}
