import Login from './Login.vue'

export default {
	install:function(Vue){
		Vue.component('Login',Login);
	}
}