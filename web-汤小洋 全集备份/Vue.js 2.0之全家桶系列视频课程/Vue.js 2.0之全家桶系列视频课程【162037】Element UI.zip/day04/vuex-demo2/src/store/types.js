/**
 * 定义类型常量
 */

const INCREMENT='INCREMENT'
const DECREMENT='DECREMENT'

export default {
	INCREMENT,
	DECREMENT
}