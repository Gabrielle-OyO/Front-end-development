<template>
	<div id="home">
		<h3>这是主页</h3>
	</div>
</template>