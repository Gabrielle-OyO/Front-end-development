<template>
	<button>自定义按钮</button>
</template>

<style scoped>
	button{
		width: 100px;
		height: 30px;
		background-color:#ccc;
		color:red;
	}
</style>