/**
 * Created by Administrator on 2017-08-30.
 */
function my$(id) {
    return document.getElementById(id);
}